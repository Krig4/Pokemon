﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pokemon
{
    class Pokemon //Información de los pokemon
    {
    }
}
